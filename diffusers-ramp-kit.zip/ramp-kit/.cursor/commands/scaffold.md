# /scaffold

Scaffold a convention-correct first contribution **and its test** for any
supported component, so a new engineer starts from green instead of a blank file.

    /scaffold <component> <Name>
    # e.g.  /scaffold scheduler EulerLite

Supported `<component>` values and their templates are declared in
`conventions/rules.yaml` under `meta.components`. This is ONE command for all
components by design — adding a component is a data change (a template + tagged
rules), not a new command. See `templates/README.md`.

## What you (the agent) must do

1. **Resolve the component.** Read `meta.components.<component>` in
   `conventions/rules.yaml` for its target `path`, `reference`, and `template`.
   If the component isn't declared, stop and say which components ARE supported.

2. **Ground yourself in current docs.** Use the `diffusers-docs` MCP tool
   (`search_docs`) for the component's conventions before writing — match the
   library's current API, not an old blog post.

3. **Copy the template** at `meta.components.<component>.template` to the target
   path, renaming the class to `<Name>...`. Satisfy every rule tagged for this
   component in the registry (they're also in the auto-attached
   `.cursor/rules/10-<component>.mdc`). Leave the domain logic (e.g. the
   numerical method) as a clearly marked `TODO` — scaffold the CONTRACT, not
   fabricated math.

4. **Create the test** from `tests/_templates/scheduler_test.py` (or the
   component's template), adjusting the class/paths. This satisfies TEST001.

5. **Run the gate before returning** and fix every blocking finding:

       python tools/convention_check.py <target-path>

   Return only when it reports 0 blocking findings.

6. **Stay in bounds.** Never read or copy from paths in `.cursorignore`. If you
   need a pattern, copy from a sibling in-repo file with a `# Copied from` marker.

## Definition of done for this command
- New component file: gate clean (0 blocking).
- New test present and passing `python -m unittest discover -s tests -t .`.
- A one-line summary of what the engineer still needs to implement.
